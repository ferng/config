module #[[$MODULE_NAME$]]# {
}